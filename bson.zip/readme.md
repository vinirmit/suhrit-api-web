Run the command

python -m pip install pymongo -t ./ to install the package locally before deploying the zip file on AWS console.